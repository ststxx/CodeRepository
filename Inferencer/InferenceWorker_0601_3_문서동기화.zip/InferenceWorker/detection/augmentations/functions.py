import cv2
import albumentations as A
import numpy as np

from augmentations.transforms import Rotate3D, GaussianShade, PartialFocus

def re_bbox(xtls, ytls, xbrs, ybrs, WIDTH, HEIGHT):
    x1s = []
    y1s = []
    x2s = []
    y2s = []
    for i in range(len(xtls)):
        x1, y1, x2, y2 = xtls[i], ytls[i], xbrs[i], ybrs[i]
        if x1 < 0:
            x1 = 0
        if y1 < 0:
            y1 = 0
        if x2 >= WIDTH:
            x2 = WIDTH - 1
        if y2 >= HEIGHT:
            y2 = HEIGHT -1
        
        x1s.append(x1)
        y1s.append(y1)
        x2s.append(x2)
        y2s.append(y2)

    return x1s, y1s, x2s, y2s

def inversion(sample, inversion_dict, p):
    ## Inversion
    augs= []
    if inversion_dict['Mirror']:
        augs.append(A.HorizontalFlip(p=p))
        
    if inversion_dict['Flip']:
        augs.append(A.VerticalFlip(p=p))

    if inversion_dict['Transpose']:
        augs.append(A.Transpose(p=p))

    transformed = A.Compose(augs, bbox_params=A.BboxParams(format='pascal_voc'))(image=sample['img'], bboxes=sample['annot'])

    sample['img'] = transformed['image']
    # sample['annot'] = transformed['bboxes']
    sample['annot'] = np.array([list(annot) for annot in transformed['bboxes']])

    return sample

def affine(sample, affine_dict, p):
    augs = []

    shift_range = affine_dict['Shift']
    zoom_range = affine_dict['Zoom']
    rotation_range = affine_dict['Rotation']

    augs.append(A.ShiftScaleRotate(shift_limit=shift_range,
                                    scale_limit=zoom_range, 
                                    rotate_limit=rotation_range, 
                                    interpolation=4, # Lanczos
                                    border_mode = affine_dict['BorderMode'], p=p))

    roll_range = affine_dict['Tilt']
    pitch_range = affine_dict['Tilt']
    
    augs.append(Rotate3D(roll=roll_range,
                            pitch=pitch_range,
                            interpolation=4,
                            border_mode=affine_dict['BorderMode'], p=p)) # Customized
    
    transformed = A.Compose(augs, bbox_params=A.BboxParams(format='pascal_voc'))(image=sample['img'], bboxes=sample['annot'])

    sample['img'] = transformed['image']
    # sample['annot'] = transformed['bboxes']
    sample['annot'] = np.array([list(annot) for annot in transformed['bboxes']])

    return sample

def color(sample, color_dict, p):
    augs = []

    brightness_range = color_dict['Brightness']
    contrast_range = color_dict['Contrast']
    shade_range = color_dict['Shade']
    hue_range = color_dict['Hue']
    saturation_range = color_dict['Saturation']

    augs.append(A.ColorJitter(brightness=brightness_range,
                                contrast=contrast_range,
                                saturation=saturation_range,
                                hue=hue_range, 
                                p=p))
    
    augs.append(GaussianShade(shade_range=shade_range, p=p)) # Customized

    sample['img'] = A.Compose(augs)(image=sample['img'].astype('uint8'))['image']
    
    return sample

def select_size(value):
    if value > 0 and value < 0.1:
        return 3
    elif value >= 0.1 and value < 0.2:
        return 5
    elif value >= 0.2 and value < 0.3:
        return 7
    elif value >= 0.3 and value < 0.4:
        return 9
    elif value >= 0.4 and value < 0.5:
        return 11
    elif value >= 0.5 and value < 0.6:
        return 13
    elif value >= 0.6 and value < 0.7:
        return 15
    elif value >= 0.7 and value < 0.8:
        return 17
    elif value >= 0.8 and value < 0.9:
        return 19
    elif value >= 0.9 and value <= 1.0:
        return 21

def filter(sample, filter_dict, p):
    augs = []

    noise_range = filter_dict['Noise']
    partialfocus_range = filter_dict['PartialFocus']

    if filter_dict['Noise']:
        augs.append(A.GaussNoise(var_limit=noise_range, p=p))
    if filter_dict['Smoothing']:
        max_kernel_size = select_size(filter_dict['Smoothing'])
        augs.append(A.GaussianBlur(blur_limit=(3, max_kernel_size), sigma_limit=0, p=p))  
    if filter_dict['PartialFocus']:
        augs.append(PartialFocus(focus_range=partialfocus_range, p=p))   
          
    sample['img'] = A.Compose(augs)(image=sample['img'])['image']

    return sample