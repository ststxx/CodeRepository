python /InferenceWorker/classification/app.py 5021 &
python /InferenceWorker/detection/core.py 5022
