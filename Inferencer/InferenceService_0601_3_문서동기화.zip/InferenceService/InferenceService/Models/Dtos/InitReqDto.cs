﻿namespace InferenceService.Models.Dtos
{
    public class InitReqDto
    {
        public string Tag { get; set; }
        public IEnumerable<string> Classes { get; set; }

        public InitReqDto(string tag, IEnumerable<string> classes)
        {
            Tag = tag;
            Classes = classes;
        }
    }
}
