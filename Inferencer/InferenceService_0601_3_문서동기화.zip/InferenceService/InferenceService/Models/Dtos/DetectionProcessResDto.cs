﻿using System.Text.Json.Serialization;

namespace InferenceService.Models.Dtos
{
    public class DetectionProcessResDto
    {
        [JsonPropertyName("result")]
        public List<DetectionProcessRes> Result { get; set; }
    }

    public class DetectionProcessRes
    {
        [JsonPropertyName("class")]
        public string Class { get; set; }
        [JsonPropertyName("confidence")]
        public double Confidence { get; set; }
        [JsonPropertyName("centerX")]
        public double CenterX { get; set; }
        [JsonPropertyName("centerY")]
        public double CenterY { get; set; }
        [JsonPropertyName("width")]
        public double Width { get; set; }
        [JsonPropertyName("height")]
        public double Height { get; set; }
    }
}
