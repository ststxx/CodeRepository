﻿using InferenceService.Models.Dtos;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace InferenceService.Controllers
{
    [Route("inference")]
    [ApiController]
    public class InferenceController : ControllerBase
    {
        string _trainOutputDir;
        HttpClient _classificationHttpClient;
        HttpClient _detectionHttpClient;
        public InferenceController(IHttpClientFactory httpClientFactory, IConfiguration config)
        {
            _trainOutputDir = config.GetConnectionString("train_output_dir");
            _classificationHttpClient = httpClientFactory.CreateClient("ClassificationHttpClient");
            _detectionHttpClient = httpClientFactory.CreateClient("DetectionHttpClient");
        }

        [HttpGet("isinit")]
        public async Task<IActionResult> IsInit([FromQuery]string aitype)
        {
            try
            {
                var ai_type = int.Parse(aitype);
                if (ai_type != 0 && ai_type != 1)
                    return BadRequest($"Invalid ai type, it should be 0(classification) or 1(detection)...input_ai_type: {ai_type}");
                var initInfoResDto = new InitInfoResDto();
                if (ai_type == 0) // classification
                    initInfoResDto = await _classificationHttpClient.GetFromJsonAsync<InitInfoResDto>($"/isinit");
                if (ai_type == 1) // detection
                    initInfoResDto = await _detectionHttpClient.GetFromJsonAsync<InitInfoResDto>($"/isinit");
                return Ok(initInfoResDto);
            }
            catch (Exception e)
            {
                return BadRequest($"Catched Exception...{e.Message}");
            }
        }

        [HttpPost("init")]
        public async Task<IActionResult> Init([FromQuery]string tag)
        {
            // 실제 아담스
            // minio에서 tag로 model 파일 찾아서 가져와 메타데이터들 다 가져와
            // 메타데이터: model tag, ai type, classes
            // model tag를 py서버로 보내면 거기서 minio에서 tag로 모델 파일 찾아서 다운받아서 사용

            // 스마트팜 대응용
            // 고정 dir에서 tag = 폴더 이름의 폴더 안에 있는 classes.json 읽어서 classes list 만들어
            // 거기 model.pt도 있는데 py서버에서 이 경로에서 model 찾아서 사용
            // tag 폴더 이름이 tag1_0 이면 ai type이 0 이라는거. 이것도 폴더이름 파싱해서 ai type 얻어
            try
            {
                var di = new DirectoryInfo(_trainOutputDir);
                if (di.Exists == false)
                    return BadRequest($"Train Output Dir is Not Exist...input_trainOutputDir: {_trainOutputDir}");
                var tags = di.GetDirectories();
                var tagDir = tags.AsQueryable().Where(x => x.Name == tag).FirstOrDefault();
                if (tagDir == null)
                    return BadRequest($"Tag is Not Exist...input_tag: {tag}");
                var tagDirStrArr = tagDir.Name.Split('_');
                var ai_type = int.Parse(tagDirStrArr[tagDirStrArr.Length - 1]);
                if (ai_type != 0 && ai_type != 1)
                    return BadRequest($"Invalid ai type, it should be 0(classification) or 1(detection)...input_ai_type: {ai_type}");
                string modelfilePath = Path.Combine(_trainOutputDir, tag, "model.pt");
                if (System.IO.File.Exists(modelfilePath) == false)
                    return BadRequest($"model.pt file is Not Exist...input file path: {modelfilePath}");
                string classesfilePath = Path.Combine(_trainOutputDir, tag, "classes.json");
                if (System.IO.File.Exists(classesfilePath) == false)
                    return BadRequest($"classes.json file is Not Exist...input file path: {classesfilePath}");
                using var streamReader = new StreamReader(classesfilePath);
                var jsonString = streamReader.ReadToEnd();
                var classes = JsonSerializer.Deserialize<List<string>>(jsonString);
                var initDto = new InitReqDto(tag, classes);
                HttpResponseMessage httpRes = new HttpResponseMessage();
                if (ai_type == 0) // classification
                    httpRes = await _classificationHttpClient.PostAsJsonAsync($"/init", initDto);
                if (ai_type == 1) // detection
                    httpRes = await _detectionHttpClient.PostAsJsonAsync($"/init", initDto);
                httpRes.EnsureSuccessStatusCode();
                return Ok(httpRes.Content.ReadFromJsonAsync<InitResDto>().Result);
            }
            catch (Exception e)
            {
                return BadRequest($"Catched Exception...{e.Message}");
            }
        }

        [HttpPost("process")]
        public async Task<IActionResult> Process(IFormFile file, [FromQuery] string aitype)
        {
            try
            {
                var ai_type = int.Parse(aitype);
                if (ai_type != 0 && ai_type != 1)
                    return BadRequest($"Invalid ai type, it should be 0(classification) or 1(detection)...input_ai_type: {ai_type}");
                var initInfoResDto = new InitInfoResDto();
                if (ai_type == 0) // classification
                    initInfoResDto = await _classificationHttpClient.GetFromJsonAsync<InitInfoResDto>($"/isinit");
                if (ai_type == 1) // detection
                    initInfoResDto = await _detectionHttpClient.GetFromJsonAsync<InitInfoResDto>($"/isinit");
                if (initInfoResDto == null)
                    return BadRequest("Inference Worker Server Connecting Error...");
                if (initInfoResDto.InitInfo.IsInit != true)
                    return BadRequest("Inference should be Initialized before Process...");
                if (file == null)
                    return BadRequest("Uploaded file is NULL...");
                using var binaryReader = new BinaryReader(file.OpenReadStream());
                byte[] data = binaryReader.ReadBytes((int)file.OpenReadStream().Length);
                ByteArrayContent bytes = new ByteArrayContent(data);
                MultipartFormDataContent multiContent = new MultipartFormDataContent();
                multiContent.Add(bytes, "file", file.FileName);
                HttpResponseMessage httpRes = new HttpResponseMessage();
                if (ai_type == 0)
                {
                    httpRes = await _classificationHttpClient.PostAsync($"/process", multiContent);
                    httpRes.EnsureSuccessStatusCode();
                    var jsonStream = httpRes.Content.ReadAsStream();
                    var classificationResult = JsonSerializer.Deserialize<ClassificationProcessResDto>(jsonStream);
                    return Ok(classificationResult);
                }
                if (ai_type == 1)
                {
                    httpRes = await _detectionHttpClient.PostAsync($"/process", multiContent);
                    httpRes.EnsureSuccessStatusCode();
                    var jsonStream = httpRes.Content.ReadAsStream();
                    var detectionResult = JsonSerializer.Deserialize<DetectionProcessResDto>(jsonStream);
                    return Ok(detectionResult);
                }
                return BadRequest($"Invalid ai type, it should be 0(classification) or 1(detection)...input_ai_type: {ai_type}");
            }
            catch (Exception e)
            {
                return BadRequest($"Catched Exception...{e.Message}");
            }
        }

        [HttpPost("deinit")]
        public async Task<IActionResult> DeInit([FromQuery] string aitype)
        {
            try
            {
                var ai_type = int.Parse(aitype);
                if (ai_type != 0 && ai_type != 1)
                    return BadRequest($"Invalid ai type, it should be 0(classification) or 1(detection)...input_ai_type: {ai_type}");
                var initInfoResDto = new InitInfoResDto();
                if (ai_type == 0) // classification
                    initInfoResDto = await _classificationHttpClient.GetFromJsonAsync<InitInfoResDto>($"/isinit");
                if (ai_type == 1) // detection
                    initInfoResDto = await _detectionHttpClient.GetFromJsonAsync<InitInfoResDto>($"/isinit");
                if (initInfoResDto == null)
                    return BadRequest("Inference Worker Server Connecting Error...");
                if (initInfoResDto.InitInfo.IsInit != true)
                    return BadRequest("There is no instance to Deinitialize...");
                HttpResponseMessage httpRes = new HttpResponseMessage();
                if (ai_type == 0)
                    httpRes = await _classificationHttpClient.PostAsync($"/deinit", null);
                if (ai_type == 1)
                    httpRes = await _detectionHttpClient.PostAsync($"/deinit", null);
                httpRes.EnsureSuccessStatusCode();
                return Ok(httpRes.Content.ReadFromJsonAsync<InitResDto>().Result);
            }
            catch (Exception e)
            {
                return BadRequest($"Catched Exception...{e.Message}");
            }
            
        }
    }
}
