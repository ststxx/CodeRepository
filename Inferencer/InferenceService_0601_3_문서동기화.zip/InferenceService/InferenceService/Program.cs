var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddHttpClient("ClassificationHttpClient", httpClient =>
{
    httpClient.BaseAddress = new Uri(builder.Configuration.GetConnectionString("classification_server"));
});
builder.Services.AddHttpClient("DetectionHttpClient", httpClient =>
{
    httpClient.BaseAddress = new Uri(builder.Configuration.GetConnectionString("detection_server"));
});

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors(builder => builder.AllowCredentials().AllowAnyHeader().AllowAnyMethod().SetIsOriginAllowed(origin => true));

app.UseAuthorization();

app.MapControllers();

app.Run();
