from default import TRAIN_OUTPUT_DIR
import torch
import torch.nn as nn
from torchvision.models import resnet50
import cv2
import albumentations as A
from albumentations.pytorch import ToTensorV2
import os
import numpy as np
import json

def ResNet50(num_classes, pretrained=False):
    model = resnet50(pretrained=pretrained)
    model.fc = nn.Linear(model.fc.in_features, num_classes)
    return model

def preprocess(image):
    image = image.copy()
    image = cv2.resize(image, dsize=(100, 100))
    base_augs = [
            A.Normalize(mean=[0.485, 0.456, 0.406], 
                        std=[0.229, 0.224, 0.225],
                        max_pixel_value=255.0,
                        p=1.0),
            ToTensorV2()
        ]
    totensor = A.Compose(base_augs)
    image_tensor = totensor(image=image)['image']
    return image_tensor

class inference:
    def __init__(self, model_tag, classes):
        # 실제 아담스
        # model_tag로 minio에서 image down해서 model path 구하기

        # 안동 대응용
        # 고정 dir에서 model_tag로 들어온 값이 폴더이름. 이 폴더 안에 model.pt 파일
        # trainoutputdir = os.path.abspath("C:/Users/st/Desktop/test_dir/train_output")
        trainoutputdir = os.path.abspath(TRAIN_OUTPUT_DIR)
        self.modelpath = os.path.join(trainoutputdir, model_tag, "model.pt")
        print('modelpath: ', self.modelpath)
        if torch.cuda.is_available():
            self.device = torch.device('cuda')
        else:
            self.device = torch.device('cpu')
        self.model = None
        self.classes = classes
    
    def initialize(self):
        checkpoint = torch.load(self.modelpath)
        self.model = ResNet50(num_classes=len(self.classes), pretrained=False)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        if torch.cuda.is_available():
            self.model.to(self.device)
        self.model.eval()
        return True
    
    def process(self, image):
        input = preprocess(image).unsqueeze(0)
        with torch.no_grad():
            if torch.cuda.is_available():
                input = input.to(self.device)
            pred = self.model(input)
            if torch.cuda.is_available():
                input = input.to(torch.device('cpu'))
                pred = pred.to(torch.device('cpu'))
        scores = torch.sigmoid(pred[0])
        scores = [score.item() for score in scores] 
        descendings = np.argsort(scores)[::-1]
        result = []
        for order in descendings:
            result.append({
                "class": self.classes[order],
                "score": scores[order]
            })
        del input
        del pred
        return result
    
    def deinitialize(self):
        if torch.cuda.is_available():
            self.model.to(torch.device('cpu'))
        del self.model
        torch.cuda.empty_cache()
