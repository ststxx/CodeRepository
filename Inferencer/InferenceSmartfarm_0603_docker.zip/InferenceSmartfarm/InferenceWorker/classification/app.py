import os
import sys
from default import PORT
import flask
from flask_cors import CORS
import logging
import cv2
import numpy as np
from core import inference
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2,3"
os.environ['WERKZEUG_RUN_MAIN'] = 'true'
app = flask.Flask(__name__)
log = logging.getLogger('werkzeug')
log.disabled = True
CORS(app)

global initInfo
initInfo = {
    "isInit": False,
    "modelTag": None,
    "aiType": None,
    "classes": None
}

global inferencer
inferencer = ""

@app.route('/isinit', methods=['GET'])
def isinit():
    try:
        global initInfo
        result = { "initInfo": initInfo }
        return flask.jsonify(result)
    except Exception as e:
        print("Exception...", e)
        result = { "isSuccess":False }
        return result

@app.route('/init', methods=['POST'])
def init():
    try:
        model_tag = flask.request.get_json(force=True)['tag']
        classes = flask.request.get_json(force=True)['classes']
        global inferencer
        inferencer = inference(model_tag, classes)
        result = { "isSuccess": inferencer.initialize() }
        global initInfo
        initInfo = {
            "isInit": True,
            "modelTag": model_tag,
            "aiType": 0,
            "classes": classes
        }
        return flask.jsonify(result)
    except Exception as e:
        print("Exception...", e)
        result = { "isSuccess":False }
        return result

@app.route('/process', methods=['POST'])
def process():
    try:
        file = flask.request.files['file']
        image = cv2.imdecode(np.frombuffer(file.read(), np.uint8), cv2.IMREAD_UNCHANGED)
        global inferencer
        result = { "result": inferencer.process(image) }
        return flask.jsonify(result)
    except Exception as e:
        print("Exception...", e)
        result = { "isSuccess":False }
        return result

@app.route('/deinit', methods=['POST'])
def deinit():
    try:
        global inferencer
        inferencer.deinitialize()
        result = { "isSuccess":True }
        global initInfo
        initInfo = {
            "isInit": False,
            "modelTag": None,
            "aiType": None,
            "classes": None
        }
        return result
    except Exception as e:
        print("Exception...", e)
        result = { "isSuccess":False }
        return result

if __name__ == '__main__':
    # port = sys.argv[1]
    print('[Running Classification Worker]')
    app.run(host='0.0.0.0', port=5021, threaded=True, debug=True)
