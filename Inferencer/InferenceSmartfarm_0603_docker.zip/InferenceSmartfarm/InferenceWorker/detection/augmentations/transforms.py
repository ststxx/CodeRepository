import cv2
import math
import numpy as np
import albumentations as A

__all__ = [
    'Rotate3D',
    'GaussianShade',
    'PartialFocus'
]

## interpolation : cv2.INTER_NEAREST(0), cv2.INTER_LINEAR(1), cv2.INTER_CUBIC(2), cv2.INTER_AREA(3), cv2.INTER_LANCZOS4(4). Default: cv2.INTER_LINEAR(1).
## border_mode   : cv2.BORDER_CONSTANT(0), cv2.BORDER_REPLICATE(1), cv2.BORDER_REFLECT(2), cv2.BORDER_WRAP(3), cv2.BORDER_REFLECT_101(4). Default: cv2.BORDER_REFLECT_101(4)
## Normalize from uint8(255) # default : mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)

def select_bbox(pts_11, pts_21, pts_12, pts_22):
    x1y1 = pts_11
    x2y1 = pts_21
    x1y2 = pts_12
    x2y2 = pts_22

    x1 = np.min([x1y1[0], x2y1[0], x1y2[0], x2y2[0]])
    x2 = np.max([x1y1[0], x2y1[0], x1y2[0], x2y2[0]])

    y1 = np.min([x1y1[1], x2y1[1], x1y2[1], x2y2[1]])
    y2 = np.max([x1y1[1], x2y1[1], x1y2[1], x2y2[1]])
    
    return np.array([x1, y1, x2, y2]).astype(np.int32)

class Rotate3D(A.DualTransform):
    def __init__(
        self,
        roll=20, 
        pitch=20,
        shift2z=0.8,
        interpolation=1,
        border_mode=1,
        value=None, # (0,0,0)
        mask_value=None,
        always_apply=False,
        p=0.5,
    ):
        super(Rotate3D, self).__init__(always_apply=always_apply, p=p)

        self.roll = roll        # should be checked for stable version. like self.__check_values(brightness, "brightness")
        self.pitch = pitch
        self.shift2z = shift2z  # 0.8
        self.interpolation = interpolation
        self.border_mode = border_mode
        self.value = value
        self.mask_value = mask_value

    def get_params_dependent_on_targets(self, params):
        self.height, self.width, _ = params['image'].shape
        
        center_hw = round(self.height/2), round(self.width/2)
        
        min_border = min(self.height, self.width)
        max_border = max(self.height, self.width)
        
        shift2z = np.random.randint(min_border+round((max_border-min_border)*self.shift2z), max_border) if (max_border-min_border) > 20 else np.random.randint(round(max_border*self.shift2z), max_border)# 0.8 # np.random.randint(min_border, max_border)

        proj2dto3d = np.array([[1,0,-center_hw[1]],
                               [0,1,-center_hw[0]],
                               [0,0,0],
                               [0,0,1]],np.float32)
        
        proj3dto2d = np.array([[shift2z,0,center_hw[1],0], # 1 -> 200
                               [0,shift2z,center_hw[0],0], # 1 -> 200
                               [0,0,1,0] ],np.float32)

        r_roll = np.random.uniform(-self.roll,self.roll) *(math.pi/180.0) if not type(self.roll) is tuple else np.random.uniform(self.roll[0],self.roll[1]) *(math.pi/180.0)
        r_pitch = np.random.uniform(-self.pitch,self.pitch) *(math.pi/180.0) if not type(self.pitch) is tuple else np.random.uniform(self.pitch[0],self.pitch[1]) *(math.pi/180.0)
        
        rx    = np.array([[1,                 0,                  0, 0],
                          [0,  math.cos(r_roll),  -math.sin(r_roll), 0],
                          [0,  math.sin(r_roll),   math.cos(r_roll), 0],
                          [0,                 0,                  0, 1]],np.float32)
        
        ry    = np.array([[math.cos(r_pitch), 0, -math.sin(r_pitch), 0],
                          [                0, 1,                  0, 0],
                          [math.sin(r_pitch), 0,  math.cos(r_pitch), 0],
                          [                0, 0,                  0, 1]],np.float32)
        
        trans = np.array([[1, 0, 0,       0],
                          [0, 1, 0,       0],
                          [0, 0, 1, shift2z],   #400 to move the image in z axis 
                          [0, 0, 0,       1]],np.float32)
        
        r = rx.dot(ry)
        self.transform_matrix = proj3dto2d.dot(trans.dot(r.dot(proj2dto3d)))
        
        return {'transform_matrix': self.transform_matrix}

    
    def apply(self, img, **params):
        return cv2.warpPerspective(img, self.transform_matrix, (params['cols'], params['rows']), None, self.interpolation, self.border_mode, self.value)
    
    def apply_to_mask(self, mask, **params): # 
        return cv2.warpPerspective(mask, self.transform_matrix, (params['cols'], params['rows']), None, self.interpolation, self.border_mode, self.mask_value)

    def apply_to_bbox(self, bbox, **params):
        xy = []
        xy.append([bbox[0] * self.width, bbox[1] * self.height, 1.])
        xy.append([bbox[2] * self.width, bbox[1] * self.height, 1.])
        xy.append([bbox[0] * self.width, bbox[3] * self.height, 1.])
        xy.append([bbox[2] * self.width, bbox[3] * self.height, 1.])
        # x1y1, x2y1, x1y2, x2y2

        xy = np.transpose(np.array(xy))

        transformed_xy = self.transform_matrix @ xy
        transformed_xy = transformed_xy[:2] / transformed_xy[2]

        selected_bbox = select_bbox(transformed_xy[:,0], transformed_xy[:,1], transformed_xy[:,2], transformed_xy[:,3])
    
        return (int(selected_bbox[0])/self.width, int(selected_bbox[1])/self.height, int(selected_bbox[2])/self.width, int(selected_bbox[3])/self.height)
    
    @property
    def targets_as_params(self):
        return ['image', 'bboxes']

    def get_transform_init_args_names(self):
        return ('roll', 
                'pitch', 
                'shift2z',
                'interpolation',
                'border_mode',
                'value',
                'mask_value',)


class GaussianShade(A.DualTransform):
    def __init__(
        self,
        shade_range=0.2,
        always_apply=False,
        p=0.5,
    ):
        super(GaussianShade, self).__init__(always_apply=always_apply, p=p)

        self.shade_range = shade_range

    def get_params_dependent_on_targets(self, params):
        height, width, channel = params['image'].shape
        
        max_border, min_border = max(height, width), min(height, width)
        min_from = np.random.randint(max_border-min_border) if (max_border!=min_border) else 0
        
        shade_range = max(1-self.shade_range, 0.1)
        k = cv2.getGaussianKernel(max_border,max_border*shade_range)
        k = np.outer(k, k.transpose())

        shade_filter = np.expand_dims((k/k.max()).clip(0,1), axis=-1)*shade_range
        shade_filter = shade_filter[:,min_from:min_from+width] if height >= width else shade_filter[min_from:min_from+height,:]

        return {'shade_filter': shade_filter}

    
    def apply(self, img, shade_filter, **params):
        return (img*shade_filter).astype('uint8')
    
    def apply_to_mask(self, mask, **params): # 
        return mask

    def apply_to_bbox(self, bbox, **params):
        return bbox

    #def apply_to_keypoint(self, keypoint, **params):
    #    return F.keypoint_vflip(keypoint, **params)
    
    @property
    def targets_as_params(self):
        return ['image']

    def get_transform_init_args_names(self):
        return ('shade_range',)

class PartialFocus(A.DualTransform):
    def __init__(
        self,
        focus_range=0.2,
        always_apply=False,
        p=0.5,
    ):
        super(PartialFocus, self).__init__(always_apply=always_apply, p=p)

        self.focus_range = focus_range

    def get_params_dependent_on_targets(self, params):
        height, width, _ = params['image'].shape

        size = 101
        focus_filter = np.zeros((size, size))

        focus_filter[:,int((size-1)/2)] = cv2.getGaussianKernel(size, 15).squeeze()

        k1 = cv2.getGaussianKernel(height, int(height * self.focus_range))
        k2 = cv2.getGaussianKernel(width, int(width * self.focus_range))
        k3 = np.outer(k1, k2)
        k = np.expand_dims(k3 / k3.max(), axis=-1)

        return {'focus_filter': focus_filter, 'k': k}
    
    def apply(self, img, focus_filter, k, **params):
        blended = (img * k) + (cv2.filter2D(img, -1, focus_filter) * (1 - k))              # 방식1
        blended = blended.astype(np.uint8)
        return blended
    
    def apply_to_mask(self, mask, **params): # 
        return mask

    def apply_to_bbox(self, bbox, **params):
        return bbox
    
    @property
    def targets_as_params(self):
        return ['image']

    def get_transform_init_args_names(self):
        return ('focus_range',)
