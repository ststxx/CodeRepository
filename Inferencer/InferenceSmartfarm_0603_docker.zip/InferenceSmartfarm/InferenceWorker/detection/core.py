from default import TRAIN_OUTPUT_DIR
import os
import os
import torch
import torch.backends.cudnn as cudnn
import numpy as np
from models.experimental import attempt_load
from utils.datasets import letterbox
from utils.general import (
    non_max_suppression, scale_coords, 
    xyxy2xywh)

def preprocess(image, img_size):
    image = image.copy()
    image = letterbox(image, new_shape=img_size)[0]
    image = image[:, :, ::-1].transpose(2, 0, 1)  # BGR to RGB, to 3x416x416
    image = np.ascontiguousarray(image)
    image_tensor = torch.from_numpy(image).float()
    image_tensor /= 255.0  # 0 - 255 to 0.0 - 1.0
    if image_tensor.ndimension() == 3:
        image_tensor = image_tensor.unsqueeze(0)
    return image_tensor

class inference:
    def __init__(self, model_tag, classes):
        # 실제 아담스
        # model_tag로 minio에서 image down해서 model path 구하기

        # 안동 대응용
        # 고정 dir에서 model_tag로 들어온 값이 폴더이름. 이 폴더 안에 model.pt 파일
        trainoutputdir = os.path.abspath(TRAIN_OUTPUT_DIR)
        self.modelpath = os.path.join(trainoutputdir, model_tag, "model.pt")
        print('modelpath: ', self.modelpath)
        if torch.cuda.is_available():
            self.device = torch.device('cuda')
        else:
            self.device = torch.device('cpu')
        self.model = None
        self.classes = classes

    def initialize(self):
        self.model = self.model = attempt_load(self.modelpath, map_location=torch.device('cpu'))
        ckpt = torch.load(self.modelpath, map_location = 'cpu')
        self.img_size = ckpt['imgsz']
        del ckpt
        return True

    def process(self, image, score_threshold):
        self.model = self.model.to(self.device)
        self.model.eval()
        self.input = preprocess(image, self.img_size).to(self.device)
        with torch.no_grad():
            self.pred = self.model(self.input, augment=False)[0].to(torch.device('cpu'))
        self.input = self.input.to(torch.device('cpu'))
        self.model = self.model.to(torch.device('cpu'))
        self.det = non_max_suppression(self.pred, score_threshold, 0.3, agnostic=False)[0]
        result = []
        gn = torch.tensor(image.shape)[[1, 0, 1, 0]]  # normalization gain whwh
        if self.det is not None and len(self.det):
            # Rescale boxes from img_size to image size
            self.det[:, :4] = scale_coords(self.input.shape[2:], self.det[:, :4], image.shape).round()
            # Write results
            for *xyxy, conf, cls in reversed(self.det):
                xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                cx, cy, w, h = xywh
                jsonRes = {
                    "class":self.classes[int(cls.item())],
                    "confidence":conf.item(),
                    "centerX":cx,
                    "centerY":cy,
                    "width":w,
                    "height":h
                }
                result.append(jsonRes)
        return result

    def deinitialize(self):
        if torch.cuda.is_available():
            self.model.to(torch.device('cpu'))
        del self.input
        del self.pred
        del self.det
        del self.model
        torch.cuda.empty_cache()