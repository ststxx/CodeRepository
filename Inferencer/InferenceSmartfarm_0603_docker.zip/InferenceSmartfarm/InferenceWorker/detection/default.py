TRAIN_OUTPUT_DIR = '/adams_data/trains/_test_trainoutputdir'
PORT = '5022'
