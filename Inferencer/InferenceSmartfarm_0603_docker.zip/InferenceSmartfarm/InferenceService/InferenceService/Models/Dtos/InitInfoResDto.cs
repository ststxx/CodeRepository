﻿using System.Text.Json.Serialization;

namespace InferenceService.Models.Dtos
{
    public class InitInfoResDto
    {
        [JsonPropertyName("initInfo")]
        public InitInfo InitInfo { get; set; }
    }

    public class InitInfo
    {
        [JsonPropertyName("isInit")]
        public bool IsInit { get; set; }
        [JsonPropertyName("modelTag")]
        public string? ModelTag { get; set; }
        [JsonPropertyName("aiType")]
        public int? AiType { get; set; }
        [JsonPropertyName("classes")]
        public IEnumerable<string>? Classes { get; set; }
    }
}
