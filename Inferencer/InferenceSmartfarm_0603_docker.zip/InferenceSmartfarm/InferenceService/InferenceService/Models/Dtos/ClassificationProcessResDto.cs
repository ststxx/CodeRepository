﻿using System.Text.Json.Serialization;

namespace InferenceService.Models.Dtos
{
    public class ClassificationProcessResDto
    {
        [JsonPropertyName("result")]
        public List<ClassificationProcessRes> Result { get; set; }
    }

    public class ClassificationProcessRes
    {
        [JsonPropertyName("class")]
        public string Class { get; set; }
        [JsonPropertyName("score")]
        public double Score { get; set; }
    }
}
