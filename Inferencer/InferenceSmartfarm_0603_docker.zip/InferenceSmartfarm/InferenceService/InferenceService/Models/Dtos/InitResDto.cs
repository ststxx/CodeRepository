﻿namespace InferenceService.Models.Dtos
{
    public class InitResDto
    {
        public bool IsSuccess { get; set; }
    }
}
